import React from 'react';

class App extends React.Component{

  constructor(props){
    super(props);
    this.state={

      counter:0,
      offset:0,
    };
  }
  onOffsetChange(event){

    this.setState({
      offset: event.target.value,
    });

  }
  onIncreement(){
    const currentValue=this.state.counter;
    const currentOffsetValue=this.state.offset;
    this.setState({
      counter: currentValue+parseInt(currentOffsetValue)
    });
  }
  onDecreement(){
    const currentValue=this.state.counter;
    const currentOffsetValue=this.state.offset;
    this.setState({
      counter: currentValue-parseInt(currentOffsetValue)
    });
  }
  render(){
    return( <div>
      <h1>Counter {this.state.counter}</h1>
      <label>Offset </label>
      <input type="number" value={this.state.offset} onChange={this.onOffsetChange.bind(this)}/><br></br>
      
      <button onClick={this.onIncreement.bind(this)}>Increement</button>
      <button onClick={this.onDecreement.bind(this)}>Decreement</button>
      </div>
    )
  }
}

export default App;
