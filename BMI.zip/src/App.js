import React from 'react';

class App extends React.Component{

  constructor(props){
    super(props);
    this.state={

      BMI:0,
      mass:0,
      height:0,
    };
  }
  onMassChange(event){

    this.setState({
      mass: event.target.value,
    });

  }
  onHeightChange(event){

    this.setState({
      height: event.target.value,
    });

  }
  onBmiButton(){
    //const currentValue=this.state.bmi;
    const currentMassValue=parseInt(this.state.mass);
    const currentHeightValue=parseInt(this.state.height);

    this.setState({
      BMI: currentMassValue/(currentHeightValue*currentHeightValue)
    });
  }
  
  render(){
    return( <div>
      <h1>BMI {this.state.BMI}</h1>
      <label>Mass </label>
      <input type="number" value={this.state.mass} onChange={this.onMassChange.bind(this)}/><br></br>
      <label>Height in meter</label>
      <input type="number" value={this.state.height} onChange={this.onHeightChange.bind(this)}/><br></br>
      <button onClick={this.onBmiButton.bind(this)}>Calculate BMI </button>
      
      </div>
    )
  }
}

export default App;
