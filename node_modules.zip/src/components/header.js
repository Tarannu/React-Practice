import React from 'react';

const Header=()=>{
    return(
        <div>
        <h1>Wallet app </h1>
        </div>
    );
}
export default Header;